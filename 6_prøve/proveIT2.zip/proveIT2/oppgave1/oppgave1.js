// Program som sier hei hvis navn er Jens

let navn = "Per";

if (navn = "Jens") {
  alert("Hei " + navn);
}
else {
  alert("Hei ukjente person");
}