const steder = {
    Oslo: {
        lat: 59.91,
        lon: 10.75
    },
    Bergen: {
        lat: 60.39,
        lon: 5.32
    },
    Kristiansand: {
        lat: 58.14,
        lon: 7.99
    },
    Sandvika: {
        lat: 60.53,
        lon: 11.18
    },
    Trondheim: {
        lat: 63.43,
        lon: 10.39
    },
}
